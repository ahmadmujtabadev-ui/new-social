"use client";

import React, { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import Header from "@/components/Homepage.tsx/header";
import { TermsCheckboxWithModal } from "@/components/common/TermsModal";
import { BOOTH_KEY, DEFAULT_PRICING, SCROLL_KEY } from "@/lib/vendorformconfig";
import ContactBusinessSection from "@/components/vendor/ContactBusinessSection";
import CategorySection from "@/components/vendor/CategorySection";
import BoothAndPaymentSection from "@/components/vendor/BoothAndPaymentSection";

// Redux imports
import { resetFormState, selectForms } from "@/redux/slices/userSlice";
import { submitVendorAsync } from "@/services/auth/asyncThunk";

// Custom hooks
import { useFormState } from "@/hooks/useFormState";
import { useBoothManagement } from "@/hooks/useBoothMaangement";
import { usePromoCode } from "@/hooks/usePromoCode";
import { validateForm } from "@/utils/vendor/formValidations";

// Event options
const EVENT_OPTIONS = [
  { value: "participating", label: "Participating" },
  { value: "sponsoring", label: "Sponsoring" },
  { value: "volunteering", label: "Volunteering" },
  { value: "setting_stall", label: "Setting Stall" },
];

const VendorForm: React.FC = () => {
  const router = useRouter();
  const dispatch = useDispatch();
  const { isLoading, vendorSuccess } = useSelector(selectForms);

  // Stepper state
  const [currentStep, setCurrentStep] = useState(1);

  // Load current step from sessionStorage on mount
  useEffect(() => {
    const savedStep = sessionStorage.getItem('vendorFormStep');
    if (savedStep) {
      setCurrentStep(parseInt(savedStep, 10));
      sessionStorage.removeItem('vendorFormStep'); // Clear after loading
    }
  }, []);

  // Custom hooks
  const {
    formData,
    setFormData,
    errors,
    setErrors,
    handleChange,
    handleFile,
    resetForm,
  } = useFormState();

  const {
    bookedBooths,
    isCheckingBooth,
  } = useBoothManagement();

  // Calculate base price
  const basePrice = useMemo(() => {
    const currentBoothNumber = formData.boothNumber;
    const stored = typeof window !== 'undefined' ? localStorage.getItem(BOOTH_KEY) : null;

    if (stored) {
      try {
        const booth = JSON.parse(stored) as { price?: number; id?: number };
        if (
          typeof booth?.price === 'number' &&
          (!currentBoothNumber || String(booth.id) === currentBoothNumber)
        ) {
          return booth.price;
        }
      } catch {
        if (formData.category) return DEFAULT_PRICING[formData.category];
        return 0;
      }
    }

    if (formData.category) return DEFAULT_PRICING[formData.category];
    return 0;
  }, [formData.category, formData.boothNumber]);

  const {
    appliedPromo,
    promoError,
    setPromoError,
    discountedPrice,
    applyPromo,
    removePromo,
    getDiscountAmount,
    discountLabel,
  } = usePromoCode(basePrice);

  // Local state
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [showBoothSuccess, setShowBoothSuccess] = useState(false);

  // Load booth from localStorage on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem(BOOTH_KEY);
      if (!raw) return;

      const booth = JSON.parse(raw) as {
        id: number;
        category: "food" | "clothing" | "jewelry" | "craft";
        price?: number;
      };

      const boothId = String(booth.id);
      if (bookedBooths.has(boothId)) {
        localStorage.removeItem(BOOTH_KEY);
        setErrors((prev) => ({
          ...prev,
          boothNumber: "This booth is no longer available. Please select another.",
        }));
        return;
      }

      setFormData((f) => ({ ...f, boothNumber: boothId }));
      setShowBoothSuccess(true);
      setTimeout(() => setShowBoothSuccess(false), 5000);
    } catch {
      return;
    }
  }, [bookedBooths, setFormData, setErrors]);

  // Restore scroll position
  useEffect(() => {
    const savedScrollPosition = sessionStorage.getItem(SCROLL_KEY);
    if (savedScrollPosition) {
      setTimeout(() => {
        window.scrollTo(0, parseInt(savedScrollPosition, 10));
        sessionStorage.removeItem(SCROLL_KEY);
      }, 100);
    }
  }, []);

  // Handle successful vendor submission
  useEffect(() => {
    if (!vendorSuccess) return;

    // Reset form after successful submission
    resetForm(true);
    dispatch(resetFormState());
    setCurrentStep(1);
  }, [vendorSuccess, dispatch, resetForm]);

  const goToMap = () => {
    const cat = formData.category
      ? `?category=${encodeURIComponent(formData.category)}`
      : "";
    try {
      if (typeof window !== 'undefined') {
        sessionStorage.setItem(SCROLL_KEY, String(window.scrollY));
        // Save current step so we can return to it
        sessionStorage.setItem('vendorFormStep', String(currentStep));
      }
    } catch {
      return;
    }
    router.push(`/booking/page${cat}`);
  };

  // Validate current step
  const validateStep = (step: number): boolean => {
    const e: Record<string, string> = {};

    if (step === 1) {
      // Validate Step 1: Business Details
      if (!formData.personName) e.personName = "Person name is required";
      if (!formData.vendorName) e.vendorName = "Vendor name is required";
      if (!formData.email) e.email = "Email is required";
      if (!formData.phone) e.phone = "Phone is required";
      if (!formData.isOakville) e.isOakville = "Please select Yes or No";
      if (!formData.selectedEvent) e.selectedEvent = "Please select an event";
    } else if (step === 2) {
      // Validate Step 2: Category Details
      if (!formData.category) e.category = "Please choose a category";

      if (formData.category === "Food Vendor") {
        if (!formData.foodItems) e.foodItems = "List up to 2 items";
        if (!formData.needPowerFood) e.needPowerFood = "Power requirement is required";
        if (formData.needPowerFood === "yes" && !formData.foodWatts)
          e.foodWatts = "Specify equipment watts";
      }
      if (formData.category === "Clothing Vendor") {
        if (!formData.clothingType) e.clothingType = "Tell us the type of clothes";
      }
      if (formData.category === "Jewelry Vendor") {
        if (!formData.jewelryType) e.jewelryType = "Tell us the jewelry type";
      }
      if (formData.category === "Craft Booth") {
        if (!formData.craftDetails) e.craftDetails = "Give some details about your items";
        if (!formData.needPowerCraft) e.needPowerCraft = "Power requirement is required";
        if (formData.needPowerCraft === "yes" && !formData.craftWatts)
          e.craftWatts = "Specify equipment watts";
      }
    } else if (step === 3) {
      // Validate Step 3: Booth & Payment
      if (!formData.boothNumber) e.boothNumber = "Please select a booth on the map";
      if (!formData.terms) e.terms = "Please accept the terms to proceed";
    }

    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep((prev) => Math.min(prev + 1, 3));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrevious = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    // Validate entire form
    const validation = validateForm(formData, bookedBooths);
    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }

    // Create payload with promo code if applied
    const payload: any = {
      ...formData,
      amountToPay: discountedPrice
    };

    if (appliedPromo) {
      payload.appliedPromoCode = appliedPromo.code;
      payload.appliedPromoDiscount = appliedPromo.discount;
    }

    // Dispatch Redux async thunk
    dispatch(submitVendorAsync(payload) as any);
  };

  const handleResetClick = () => {
    resetForm(false);
    setSubmitError(null);
    setCurrentStep(1);
  };

  const discountAmount = getDiscountAmount();

  // Stepper component
  const steps = [
    { number: 1, title: "Business Details", description: "Contact & Business Information" },
    { number: 2, title: "Category", description: "Select Category & Details" },
    { number: 3, title: "Booth & Payment", description: "Select Booth & Review" },
  ];

  return (
    <div className="min-h-screen bg-black">
      <Header />
      <div className="relative w-full mx-auto px-4 md:px-8 lg:px-20 py-16">
        {/* Header Section with Gradient Background */}
        <div className="text-center mb-12 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/10 via-purple-500/10 to-pink-500/10 blur-3xl -z-10"></div>
          <h1 className="relative text-4xl md:text-6xl font-extrabold bg-gradient-to-r from-yellow-500 via-yellow-400 to-yellow-600 bg-clip-text text-transparent mb-4">
            Vendor Registration
          </h1>
          <p className="relative text-gray-300 text-base md:text-lg max-w-2xl mx-auto">
            Complete this form to register as a vendor. Follow the 3-step process to complete your application.
          </p>
        </div>

        {/* Stepper */}
        <div className="mb-12">
          <div className="flex items-center justify-between max-w-3xl mx-auto">
            {steps.map((step, index) => (
              <React.Fragment key={step.number}>
                <div className="flex flex-col items-center flex-1">
                  <div
                    className={`w-12 h-12 md:w-16 md:h-16 rounded-full flex items-center justify-center font-black text-lg md:text-xl transition-all duration-300 ${
                      currentStep === step.number
                        ? "bg-gradient-to-br from-yellow-400 to-yellow-600 text-black scale-110 shadow-lg shadow-yellow-400/50"
                        : currentStep > step.number
                        ? "bg-emerald-500 text-white"
                        : "bg-gray-700 text-gray-400"
                    }`}
                  >
                    {currentStep > step.number ? (
                      <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    ) : (
                      step.number
                    )}
                  </div>
                  <div className="mt-2 text-center hidden md:block">
                    <p
                      className={`text-sm font-bold ${
                        currentStep >= step.number ? "text-yellow-400" : "text-gray-500"
                      }`}
                    >
                      {step.title}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">{step.description}</p>
                  </div>
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`flex-1 h-1 mx-2 transition-all duration-300 ${
                      currentStep > step.number
                        ? "bg-gradient-to-r from-emerald-500 to-yellow-400"
                        : "bg-gray-700"
                    }`}
                  />
                )}
              </React.Fragment>
            ))}
          </div>

          {/* Mobile step title */}
          <div className="mt-6 text-center md:hidden">
            <p className="text-yellow-400 font-bold text-lg">{steps[currentStep - 1].title}</p>
            <p className="text-gray-400 text-sm">{steps[currentStep - 1].description}</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Step 1: Business Details */}
          {currentStep === 1 && (
            <div className="transition-all duration-500 ease-in-out">
              <ContactBusinessSection
                formData={formData}
                errors={errors}
                onChange={handleChange}
                onFileChange={handleFile}
              />
            </div>
          )}

          {/* Step 2: Category Details */}
          {currentStep === 2 && (
            <div className="transition-all duration-500 ease-in-out">
              <CategorySection
                formData={formData}
                errors={errors}
                onChange={handleChange}
                onFileChange={handleFile}
              />
            </div>
          )}

          {/* Step 3: Booth & Payment */}
          {currentStep === 3 && (
            <div className="transition-all duration-500 ease-in-out space-y-8">
              <BoothAndPaymentSection
                formData={formData}
                errors={errors}
                basePrice={basePrice}
                discountedPrice={discountedPrice}
                appliedPromo={appliedPromo}
                promoError={promoError}
                discountAmount={discountAmount}
                onChange={handleChange}
                discountLabel={discountLabel}
                showBoothSuccess={showBoothSuccess}
                onGoToMap={goToMap}
                onClearBooth={() => {
                  setFormData((f) => ({ ...f, boothNumber: "" }));
                  try {
                    localStorage.removeItem(BOOTH_KEY);
                  } catch {
                    return;
                  }
                }}
                onPromoChange={(value) => {
                  setFormData((f) => ({ ...f, promoCode: value }));
                  setPromoError("");
                }}
                onApplyPromo={() => applyPromo(formData.promoCode)}
                onRemovePromo={removePromo}
              />

              {isCheckingBooth && (
                <div className="text-center text-yellow-400 font-semibold animate-pulse">
                  Checking booth availability...
                </div>
              )}

              <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700 rounded-2xl p-6 hover:border-gray-600 transition-colors duration-300">
                <label className="block text-gray-300 font-semibold mb-2">
                  Notes (optional)
                </label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleChange}
                  rows={4}
                  className="w-full bg-gray-700/50 border border-gray-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all duration-200"
                  placeholder="Any additional information you'd like to share..."
                />
              </div>

              <TermsCheckboxWithModal
                checked={formData.terms}
                error={errors.terms}
                onChange={(checked) =>
                  setFormData((prev) => ({ ...prev, terms: checked }))
                }
              />

              {submitError && (
                <div className="bg-red-500/10 border border-red-500/50 rounded-xl p-4 transition-all duration-300">
                  <p className="text-red-400 text-center text-sm font-semibold">
                    {submitError}
                  </p>
                </div>
              )}

              {vendorSuccess && (
                <div className="bg-emerald-500/10 border border-emerald-500/50 rounded-xl p-4 transition-all duration-300">
                  <p className="text-emerald-400 text-center text-sm font-semibold">
                    Thank you for applying! Your booth is reserved for the next 48 hours. Please complete the next steps we send you to confirm your booking.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex flex-wrap gap-4 justify-center mt-10">
            {currentStep > 1 && (
              <button
                type="button"
                onClick={handlePrevious}
                className="bg-transparent text-gray-400 px-10 py-4 rounded-full border-2 border-gray-600 text-base font-bold hover:bg-gray-700 hover:text-white transition-all duration-300"
              >
                ← Previous
              </button>
            )}

            {currentStep < 3 && (
              <button
                type="button"
                onClick={handleNext}
                className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-black px-10 py-4 rounded-full text-base font-black tracking-wide shadow-xl shadow-yellow-400/40 hover:shadow-2xl hover:shadow-yellow-400/60 hover:scale-105 transition-all duration-300 transform"
              >
                Next →
              </button>
            )}

            {currentStep === 3 && (
              <>
                <button
                  type="submit"
                  disabled={isLoading || isCheckingBooth}
                  className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-black px-10 py-4 rounded-full text-base font-black tracking-wide shadow-xl shadow-yellow-400/40 hover:shadow-2xl hover:shadow-yellow-400/60 hover:scale-105 transition-all duration-300 transform disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
                >
                  {isLoading ? "Submitting…" : "Submit for Review"}
                </button>

                <button
                  type="button"
                  onClick={handleResetClick}
                  className="bg-transparent text-[#f0b400] px-10 py-4 rounded-full border-2 border-[#f0b400] text-base font-bold hover:bg-[#f0b400] hover:text-black transition-all duration-300"
                >
                  Clear Form
                </button>
              </>
            )}
          </div>

          {/* Progress indicator */}
          <div className="text-center text-gray-500 text-sm mt-6">
            Step {currentStep} of 3
          </div>
        </form>
      </div>
    </div>
  );
};

export default VendorForm;