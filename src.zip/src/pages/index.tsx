import React from "react";
import HomePage from "./HomePage";

function Main() {
  return (
    <>
      <HomePage />
    </>
  );
}

export default Main;
