// src/config/index.ts

/*import { API_BASE_URL } from "./apiconfig";

// Unified config object
const config = {
  API_ENDPOINT: API_BASE_URL,
};

export default config;
*/