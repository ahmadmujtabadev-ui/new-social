export const AfterAuth = ["/home"];
