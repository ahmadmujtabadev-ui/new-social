// src/services/dashboard/endpoints.ts
import { HttpService } from "../index";

class DashboardService extends HttpService {
  private readonly prefix = "api"; // if your API_BASE is /api
  // If your backend is /api/v1 then use: private readonly prefix = "api/v1";

  vendors = (params?: any) => this.get(`${this.prefix}/vendors`, params);

  sponsors = (params?: any) => this.get(`${this.prefix}/sponsors`, params);

  booths = (params?: any) => this.get(`${this.prefix}/booths`, params);

  stats = () => this.get(`${this.prefix}/vendors/stats`);

  updateVendor = (id: string, updates: any) =>
    this.put(`${this.prefix}/vendors/${id}`, updates);

  deleteVendor = (id: string) =>
    this.delete(`${this.prefix}/vendors/${id}`);

  updateSponsor = (id: string, updates: any) =>
    this.put(`${this.prefix}/sponsors/${id}`, updates);

  deleteSponsor = (id: string) =>
    this.delete(`${this.prefix}/sponsors/${id}`);
}

export const dashboardService = new DashboardService();
