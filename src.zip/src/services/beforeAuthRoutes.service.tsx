export const BeforeAuth = ["/login", "Signup"];
