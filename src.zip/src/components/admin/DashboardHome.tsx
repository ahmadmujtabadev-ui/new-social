// src/components/admin/DashboardHome.tsx
import React, { useEffect } from 'react';
import { useAppDispatch, useAppSelector } from '@/hooks/hooks';
import {
  Users,
  Trophy,
  Store,
  TrendingUp,
  Clock,
  CheckCircle,
} from 'lucide-react';
import Link from 'next/link';
import { fetchSponsors, fetchStats, fetchVendors } from '@/services/dashbord/asyncThunk';

const DashboardHome: React.FC = () => {
  const dispatch = useAppDispatch();
  const { stats, vendors, loading } = useAppSelector((state) => state.dashboard);
  console.log("stats",stats)

  useEffect(() => {
    dispatch(fetchStats());
    dispatch(fetchVendors());
    dispatch(fetchSponsors());
  }, [dispatch]);

  const recentVendors = vendors.slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-lg p-6 text-gray-900 border border-yellow-600/30">
        <h2 className="text-2xl font-bold mb-2">Welcome to Admin Dashboard</h2>
        <p className="text-gray-800">
          Manage your event vendors, sponsors, and booth assignments all in one place
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-black rounded-lg border border-yellow-500 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Vendors</p>
              <p className="text-3xl font-bold text-yellow-500 mt-2">
                {stats?.vendors?.total || 0}
              </p>
              <p className="text-sm text-yellow-400 mt-1">↑ Active registrations</p>
            </div>
            <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-yellow-500" />
            </div>
          </div>
        </div>

        <div className="bg-black rounded-lg border border-yellow-500 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Approved</p>
              <p className="text-3xl font-bold text-yellow-500 mt-2">
                {stats?.vendors?.approved || 0}
              </p>
              <p className="text-sm text-yellow-400 mt-1">✓ Confirmed vendors</p>
            </div>
            <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-yellow-500" />
            </div>
          </div>
        </div>

        <div className="bg-black rounded-lg border border-yellow-500 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Pending</p>
              <p className="text-3xl font-bold text-yellow-500 mt-2">
                {stats?.vendors?.submitted || 0}
              </p>
              <p className="text-sm text-yellow-400 mt-1">⏳ Awaiting approval</p>
            </div>
            <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <Clock className="w-6 h-6 text-yellow-500" />
            </div>
          </div>
        </div>

        <div className="bg-black rounded-lg border border-yellow-500 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Sponsors</p>
              <p className="text-3xl font-bold text-yellow-500 mt-2">
                {stats?.sponsors?.total || 0}
              </p>
              <p className="text-sm text-yellow-400 mt-1">★ Active partnerships</p>
            </div>
            <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <Trophy className="w-6 h-6 text-yellow-500" />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-black rounded-lg border border-yellow-600/30 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <Store className="w-5 h-5 text-yellow-500" />
            </div>
            <h3 className="text-lg font-semibold text-yellow-500">Booth Status</h3>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Available</span>
              <span className="text-sm font-medium text-yellow-500">
                {stats?.booths?.available || 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Held</span>
              <span className="text-sm font-medium text-yellow-400">
                {stats?.booths?.held || 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Booked</span>
              <span className="text-sm font-medium text-yellow-500">
                {stats?.booths?.booked || 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Confirmed</span>
              <span className="text-sm font-medium text-yellow-500">
                {stats?.booths?.confirmed || 0}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-black rounded-lg border border-yellow-600/30 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <Trophy className="w-5 h-5 text-yellow-500" />
            </div>
            <h3 className="text-lg font-semibold text-yellow-500">Sponsor Tiers</h3>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Platinum</span>
              <span className="text-sm font-medium text-yellow-500">
                {stats?.sponsors?.byTier?.['PLATINUM SPONSOR'] || 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Gold</span>
              <span className="text-sm font-medium text-yellow-400">
                {stats?.sponsors?.byTier?.['GOLD SPONSOR'] || 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Silver</span>
              <span className="text-sm font-medium text-gray-500">
                {stats?.sponsors?.byTier?.['SILVER SPONSOR'] || 0}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-black rounded-lg border border-yellow-600/30 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-yellow-500" />
            </div>
            <h3 className="text-lg font-semibold text-yellow-500">Vendor Categories</h3>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Food Vendors</span>
              <span className="text-sm font-medium text-yellow-500">
                {stats?.vendors?.byCategory?.['Food Vendor'] || 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Craft Booths</span>
              <span className="text-sm font-medium text-yellow-500">
                {stats?.vendors?.byCategory?.['Craft Booth'] || 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Clothing</span>
              <span className="text-sm font-medium text-yellow-500">
                {stats?.vendors?.byCategory?.['Clothing Vendor'] || 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Jewelry</span>
              <span className="text-sm font-medium text-yellow-500">
                {stats?.vendors?.byCategory?.['Jewelry Vendor'] || 0}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-black rounded-lg border border-yellow-500">
        <div className="px-6 py-4 border-b border-yellow-500 flex items-center justify-between">
          <h3 className="text-lg font-semibold text-yellow-500">Recent Vendor Registrations</h3>
          <Link
            href="/admin/vendors"
            className="text-sm text-yellow-500 hover:text-yellow-400 font-medium"
          >
            View All →
          </Link>
        </div>
        <div className="p-6">
          {loading ? (
            <div className="text-center py-8 text-gray-400">Loading...</div>
          ) : recentVendors.length === 0 ? (
            <div className="text-center py-8 text-gray-400">No recent activity</div>
          ) : (
            <div className="space-y-4">
              {recentVendors.map((vendor) => (
                <div
                  key={vendor._id}
                  className="flex items-center justify-between py-3 border-b border-gray-800 last:border-0"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                      <Store className="w-5 h-5 text-yellow-500" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-300">{vendor.vendorName}</p>
                      <p className="text-xs text-gray-500">{vendor.category}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-300">
                        Booth #{vendor.boothNumber || 'N/A'}
                      </p>
                      <p className="text-xs text-gray-500">
                        {vendor.bookingTimeline?.submittedAt
                          ? new Date(vendor.bookingTimeline.submittedAt).toLocaleDateString()
                          : vendor.createdAt
                          ? new Date(vendor.createdAt).toLocaleDateString()
                          : 'N/A'}
                      </p>
                    </div>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        vendor.status === 'approved'
                          ? 'bg-yellow-500/20 text-yellow-500'
                          : vendor.status === 'held'
                          ? 'bg-yellow-400/20 text-yellow-400'
                          : vendor.status === 'confirmed'
                          ? 'bg-yellow-500/20 text-yellow-500'
                          : vendor.status === 'expired'
                          ? 'bg-gray-700 text-gray-400'
                          : 'bg-gray-700 text-gray-400'
                      }`}
                    >
                      {vendor.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-2 gap-6">
        <Link
          href="/admin/vendors"
          className="bg-black rounded-lg border border-yellow-500 p-6 hover:border-yellow-400 transition group"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center group-hover:bg-yellow-500/30 transition">
              <Users className="w-6 h-6 text-yellow-500" />
            </div>
            <div>
              <h4 className="text-lg font-semibold text-yellow-500">Manage Vendors</h4>
              <p className="text-sm text-gray-400">View and update vendor status</p>
            </div>
          </div>
        </Link>

        <Link
          href="/admin/sponsors"
          className="bg-black rounded-lg border border-yellow-500 p-6 hover:border-yellow-400 transition group"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center group-hover:bg-yellow-500/30 transition">
              <Trophy className="w-6 h-6 text-yellow-500" />
            </div>
            <div>
              <h4 className="text-lg font-semibold text-yellow-500">Manage Sponsors</h4>
              <p className="text-sm text-gray-400">View sponsor partnerships</p>
            </div>
          </div>
        </Link>
      </div>
    </div>
  );
};

export default DashboardHome;